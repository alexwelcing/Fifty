$(function () {
    $('.editableTable').editableTableWidget();
});