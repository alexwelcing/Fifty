$(function () {
    $('.pickadate').pickadate();
});