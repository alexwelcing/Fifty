<!-- /.box-header -->
<div class="box-body table-responsive no-padding">
    <table class="table table-hover">
        <tbody>
            <tr>
                <th>Sr.</th>
                <th>Table</th>
                <th>Question</th>
                <th>status</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $sectiondata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($k+1); ?></td>
                <td><a href="<?php echo e(route('sectionsdata.show', [$statesthreefourty->id,$section->id,$sectiondata->id ])); ?>"><?php if($sectiondata->table_select == '1'): ?> Table 1 <?php else: ?> Table2 <?php endif; ?></a></td>
                
                <td> <?php echo e($sectiondata->questions->question); ?></td>
                <td>
                  <?php if($sectiondata->active =='1'): ?>
                   <i class="fa fa-check success"></i>
                    <?php else: ?>
                     <i class="fa fa-times danger"></i>
                      <?php endif; ?>
                    </td>
                <td>
                    <a href="<?php echo e(route('sectionsdata.edit', [$statesthreefourty->id,$section->id, $sectiondata->id])); ?>">
                        <i class="fa fa-pencil info"></i>
                    </a>
                    <a data-method="Delete" data-confirm="Are you sure?" href="<?php echo e(route('sections.destroy', [$statesthreefourty->id, $section->id,$sectiondata->id])); ?>">
                        <i class="fa fa-trash-o danger"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<!-- /.box-body -->