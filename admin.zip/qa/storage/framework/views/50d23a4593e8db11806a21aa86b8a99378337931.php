<div class="form-group <?php echo ($errors->has('question') ? 'has-error' : ''); ?>">
    <?php echo Form::label('question','Question', ['class' => 'control-label']); ?>

    <?php echo Form::text('question', null, ['class' => 'form-control' . ($errors->has('question') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('question', '<span class="help-block">:message</span>'); ?>

</div>



<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>