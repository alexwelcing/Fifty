<div class="form-group <?php echo ($errors->has('color') ? 'has-error' : ''); ?>">
    <?php echo Form::label('color','Colorsfdsfsdf', ['class' => 'control-label']); ?>

    <?php echo Form::text('color', null, ['class' => 'form-control my-colorpicker1' . ($errors->has('color') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('color', '<span class="help-block">:message</span>'); ?>


   
</div>

<div class="form-group <?php echo ($errors->has('hoverColor') ? 'has-error' : ''); ?>">
    <?php echo Form::label('hoverColor','Hover Color', ['class' => 'control-label']); ?>

    <?php echo Form::text('hoverColor', null, ['class' => 'form-control my-colorpicker1' . ($errors->has('hoverColor') ? ' is-invalid' : ''), 'maxlength' => 2]); ?>

    <?php echo $errors->first('hoverColor', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>




