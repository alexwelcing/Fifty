

<?php $__env->startSection('content'); ?>
<section class="content">                    
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">List <?php echo e($title); ?></h3>
                   
                    <div class="pull-right">
                        <a href="<?php echo e(route('statesthreefourty.show', [$statesthreefourty->id,$section->id])); ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Back</a>
                        <a href="<?php echo e(route('sectionsdata.create', [$statesthreefourty->id,$section->id])); ?>" class="btn btn-success"><i class="fa fa-plus"></i> Add</a>
                    </div>
                </div>
                
                <?php echo $__env->make('admin.statesthreefourty.sectiondata.partials.table',['datas' => $sectiondata], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>