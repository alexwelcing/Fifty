<div class="form-group <?php echo ($errors->has('fname') ? 'has-error' : ''); ?>">
    <?php echo Form::label('fname','First Name', ['class' => 'control-label']); ?>

    <?php echo Form::text('fname', null, ['class' => 'form-control' . ($errors->has('fname') ? ' is-invalid' : ''), 'maxlength' => 100]); ?>

    <?php echo $errors->first('fname', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('lname') ? 'has-error' : ''); ?>">
    <?php echo Form::label('lname','Last Name', ['class' => 'control-label']); ?>

    <?php echo Form::text('lname', null, ['class' => 'form-control' . ($errors->has('lname') ? ' is-invalid' : ''), 'maxlength' => 100]); ?>

    <?php echo $errors->first('lname', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email','Email', ['class' => 'control-label']); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : '')]); ?>

    <?php echo $errors->first('lname', '<span class="help-block">:message</span>'); ?>

</div>
<?php if(Request::segment(4)!='edit'): ?>
<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
				<input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" required>
				<?php if($errors->has('password')): ?>
				<span class="invalid-feedback" role="alert">
					<strong><?php echo e($errors->first('password')); ?></strong>
				</span>
				<?php endif; ?>
			</div>
			
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
				<input type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation" placeholder="<?php echo e(__('Confirm Password')); ?>" required>
			</div>
<?php endif; ?>
<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>