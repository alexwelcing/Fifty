<?php echo Form::hidden('sections_id', $section->id); ?>

<?php echo Form::hidden('users_id', auth()->user()->id); ?>

<div class="form-group <?php echo ($errors->has('question_type') ? 'has-error' : ''); ?>">
    <?php echo Form::label('table_select','Table Type', ['class' => 'control-label']); ?>    
    <?php echo Form::select('table_select', array('1' => 'Table 1', '2' => 'Table 2'), null, ['class' => 'form-control' . ($errors->has('table_rows') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('table-select', '<span class="help-block">:message</span>'); ?>

</div>
<div class="form-group <?php echo ($errors->has('questions_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('questions_id','Questions', ['class' => 'control-label']); ?>

    <?php echo Form::select('questions_id', $questions, null, ['class' => 'form-control' . ($errors->has('questions_id') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('questions_id', '<span class="help-block">:message</span>'); ?>

</div>

<div id= "tabl1">
<div class="form-group <?php echo ($errors->has('ingredient_cost') ? 'has-error' : ''); ?>">
    <?php echo Form::label('ingredient_cost','Ingredient Cost', ['class' => 'control-label']); ?>

    <?php echo Form::text('ingredient_cost', null, ['class' => 'form-control' . ($errors->has('ingredient_cost') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('ingredient_cost', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('dispensing_fee') ? 'has-error' : ''); ?>">
    <?php echo Form::label('dispensing_fee','Dispensing Fee', ['class' => 'control-label']); ?>

    <?php echo Form::text('dispensing_fee', null, ['class' => 'form-control' . ($errors->has('dispensing_fee') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('dispensing_fee', '<span class="help-block">:message</span>'); ?>

</div>


<div class="form-group <?php echo ($errors->has('clarifying_detail') ? 'has-error' : ''); ?>">
    <?php echo Form::label('clarifying_detail','Clarifying Detail', ['class' => 'control-label']); ?>

    <?php echo Form::text('clarifying_detail', null, ['class' => 'form-control clr' . ($errors->has('clarifying_detail') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('clarifying_detail', '<span class="help-block">:message</span>'); ?>

</div></div>

<div id="tbl2">
    <div class="form-group <?php echo ($errors->has('clarifying_detail') ? 'has-error' : ''); ?>">
    <?php echo Form::label('clarifying_detail','Answer', ['class' => 'control-label']); ?>

    <?php echo Form::text('clarifying_detail', null, ['class' => 'form-control ans' . ($errors->has('clarifying_detail') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('clarifying_detail', '<span class="help-block">:message</span>'); ?>

</div>
    </div>
  
<div class="form-group <?php echo ($errors->has('source') ? 'has-error' : ''); ?>">
    <?php echo Form::label('source','Source', ['class' => 'control-label']); ?>

    <?php echo Form::text('source', null, ['class' => 'form-control' . ($errors->has('source') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('source', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('source_link') ? 'has-error' : ''); ?>">
    <?php echo Form::label('source_link','Source Link', ['class' => 'control-label']); ?>

    <?php echo Form::text('source_link', null, ['class' => 'form-control' . ($errors->has('source_link') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('source_link', '<span class="help-block">:message</span>'); ?>

</div>
<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>

<?php $__env->startSection('script'); ?>
<script>
  
$(document).ready(function(){
    $("#tbl2").hide();
  
    $(".ans").attr('disabled','disabled');
$('#table_select').on('change', function() {
  //alert( this.value );
if(this.value == 2){
     $("#tbl2").show();
     $("#tabl1").hide();
     $(".ans").removeAttr('disabled');
     $("#ingredient_cost").hide();
     $("#ingredient_cost").attr('disabled','disabled');
     $("#ingredient_cost").removeAttr('name');
     ("#dispensing_fee").hide();
      $("#dispensing_fee").attr('disabled','disabled');
      $("#dispensing_fee").removeAttr('name');
      $(".clr").hide();
      $(".clr").removeAttr('name');
       $(".clr").attr('disabled','disabled');

   
  
}else{
     $("#tabl1").show();
   $("#tbl2").hide();
    $(".ans").attr('disabled','disabled');
    $("#ingredient_cost").show();
    $("#ingredient_cost").removeAttr('disabled');
      $("#dispensing_fee").removeAttr('disabled');
       $("#clarifying_detail").removeAttr('disabled');
}

});
});
</script>
<?php $__env->stopSection(); ?>