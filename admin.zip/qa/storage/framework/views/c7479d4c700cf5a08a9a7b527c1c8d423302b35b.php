<div class="form-group <?php echo ($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title','Title', ['class' => 'control-label']); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control' . ($errors->has('title') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('title', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('first_heading') ? 'has-error' : ''); ?>">
    <?php echo Form::label('first_heading','First Heading', ['class' => 'control-label']); ?>

    <?php echo Form::text('first_heading', null, ['class' => 'form-control' . ($errors->has('first_heading') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('first_heading', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('second_heading') ? 'has-error' : ''); ?>">
    <?php echo Form::label('second_heading','Second Heading', ['class' => 'control-label']); ?>

    <?php echo Form::text('second_heading', null, ['class' => 'form-control' . ($errors->has('second_heading') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('second_heading', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('states_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('states_id','States', ['class' => 'control-label']); ?>

    <?php echo Form::select('states_id', $states, null, ['class' => 'form-control' . ($errors->has('states_id') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('states_id', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('table_rows') ? 'has-error' : ''); ?>">
    <?php echo Form::label('table_rows','Rows', ['class' => 'control-label']); ?>    
    <?php echo Form::select('table_rows', array('1' => 'One', '2' => 'Two'), null, ['class' => 'form-control' . ($errors->has('table_rows') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('table_rows', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>