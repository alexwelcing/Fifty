<!-- /.box-header -->
<div class="box-body table-responsive no-padding">
    <table class="table table-hover">
        <tbody>
            <tr>
                <th>Sr.</th>
                <th>Description</th>
                <?php if($data->table_rows=='2'): ?>
                <th>Description 2</th>
                <?php endif; ?>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($k+1); ?></td>
                <td><?php echo $faq->description; ?></td>
                <?php if($data->table_rows=='2'): ?>
                <td><?php echo $faq->description2; ?></td>
                <?php endif; ?>
                <td>
                    <a href="<?php echo e(route('faqs.edit', [$data->id, $faq->id])); ?>">
                        <i class="fa fa-pencil info"></i>
                    </a>
                    <a data-method="Delete" data-confirm="Are you sure?" href="<?php echo e(route('faqs.destroy', [$data->id, $faq->id])); ?>">
                        <i class="fa fa-trash-o danger"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<!-- /.box-body -->