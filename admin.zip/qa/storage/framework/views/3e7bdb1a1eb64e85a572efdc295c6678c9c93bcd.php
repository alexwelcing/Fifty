<aside class="sidebar-left">
    <section class="sidebar">
	
		<div class="user-panel">
<div class="pull-left image">
<img src="resources/img/icons/icon-user.png" class="img-circle" alt="User Image">
</div>
<div class="info">
<p>Brian Mayer</p>
<p><small>Driver</small>
</p>
<a href="#"><i class="fa fa-circle text-success"></i> Online</a>
</div>

</div>
	
        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">
            
            <!--Dashboard-->
            <li class="treeview <?php echo e(($active=='dashboard'?'active':'')); ?>"><a href="<?php echo e(route('admin.dashboard.index')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>


            <!--States-->
            <li class="treeview <?php echo e(($active=='states'?'active':'')); ?>"><a href="<?php echo e(route('states.index')); ?>"><i class="fa fa-globe"></i> <span>States</span></a></li>

            <!--categories-->
            <li class="treeview <?php echo e(($active=='categories'?'active':'')); ?>"><a href="<?php echo e(route('categories.index')); ?>"><i class="fa fa-forward"></i> <span>Categories</span></a></li>

            <!--states data-->
            <li class="treeview <?php echo e(($active=='datas'?'active':'')); ?>"><a href="<?php echo e(route('datas.index')); ?>"><i class="fa fa-database"></i> <span>States Data</span></a></li>

             <!--maps data-->
            <li class="treeview <?php echo e(($active=='maps'?'active':'')); ?>"><a href="<?php echo e(route('maps.index')); ?>"><i class="fa fa-map-o"></i> <span>Maps Data</span></a></li>
			<!---Questions data-->
            <li class="treeview <?php echo e(($active=='questions'?'active':'')); ?>"><a href="<?php echo e(route('questions.index')); ?>"><i class="fa fa-question-circle-o"></i><span>Questions</span>
           
		   <li class="treeview <?php echo e(($active=='statesthreefourty'?'active':'')); ?>"><a href="<?php echo e(route('statesthreefourty.index')); ?>"><i class="fa fa-question-circle-o"></i><span>States 340 B</span>
			
             <li class="treeview <?php echo e(($active=='uploadcsv'?'active':'')); ?>"><a href="<?php echo e(route('uploadcsv.create')); ?>"><i class="fa fa-question-circle-o"></i><span>Upload CSV</span>

            <li class="treeview <?php echo e(($active=='uploadstatecsv'?'active':'')); ?>"><a href="<?php echo e(route('uploadstatecsv.create')); ?>"><i class="fa fa-question-circle-o"></i><span>Uploadstatecsv</span>
            <?php if(auth()->user()->roles_id=='1'): ?>
			<!---Users data-->
			<li class="treeview <?php echo e(($active=='users'?'active':'')); ?>"><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-users"></i><span>Users</span>
			
			<?php endif; ?>
			
 
        </ul>
        <!-- /. sidebar-menu -->
    </section>
</aside>