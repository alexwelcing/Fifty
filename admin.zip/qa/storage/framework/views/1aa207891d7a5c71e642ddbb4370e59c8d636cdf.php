<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-form">
                <div class="box-header">
                    <h3 class="box-title">Show <?php echo e($title); ?></h3>
                    <a href="<?php echo e(route('sectionsdata.index', [$statesthreefourty->id,$section->id])); ?>" class="btn btn-success pull-right"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="col-md-12">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($sectiondata->sections->title); ?></h3>
                            <div class="pull-right">		                        
		                        <a href="<?php echo e(route('sectionsdata.edit', [$statesthreefourty->id, $section->id,$sectiondata->id])); ?>" class="btn btn-warning"><i class="fa fa-edit"></i> Edit</a>
		                        
								<?php if(auth()->user()->roles_id=='1'): ?>
								<a data-method="Delete" data-confirm="Are you sure?" class="btn btn-danger" href="<?php echo e(route('sectionsdata.destroy', [$statesthreefourty->id, $section->id,$sectiondata->id])); ?>">
									<i class="fa fa-trash-o danger"></i> Delete
								</a>
								<?php endif; ?>
								
                                
							</div>
                        </div>
						<div class="col-md-12">
							
							
							<p><strong>Table:</strong> <?php if($sectiondata->table_select == '1'): ?> Table 1 <?php else: ?> Table2 <?php endif; ?></p>
                            <p><strong>Question:</strong> <?php echo e($sectiondata->questions->question); ?></p>
                          <?php if($sectiondata->table_select == '1'): ?>

                            <p><strong>Ingredient Cost:</strong><?php echo e($sectiondata->ingredient_cost); ?></p>
                            <p><strong>Dispensing Fee:</strong><?php echo e($sectiondata->dispensing_fee); ?></p>
                            <p><strong>Clarifying Detail:</strong><?php echo e($sectiondata->clarifying_detail); ?></p>
                            <?php else: ?>
                            <p><strong>Answer:</strong><?php echo e($sectiondata->clarifying_detail); ?></p>
						   <?php endif; ?>

                           <p><strong>Source:</strong> <?php echo e($sectiondata->source); ?></p>
                           <p><strong>Source Link:</strong> <?php echo e($sectiondata->source_link); ?></p>
						</div>

						<div class="col-md-12">
	                        
						</div>
                        
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>