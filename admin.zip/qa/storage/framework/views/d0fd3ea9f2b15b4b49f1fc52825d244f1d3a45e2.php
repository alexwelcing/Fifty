<?php $__env->startSection('content'); ?>
<section class="content">                    
    <!-- /.row -->
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">List <?php echo e($title); ?></h3>
                    <a href="<?php echo e(route('statesthreefourty.create')); ?>" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add</a>
                </div>
                
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody>
                            <tr>
                                <th>Sr.</th>
								
                                <th>Title</th>
								<th>States</th>
                                <th>Description</th>
                                
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $statesthreefourty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $states_th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($k+1); ?></td>
                                <td><a href="<?php echo e(route('statesthreefourty.show', $states_th->id)); ?>"><?php echo e($states_th->title); ?></a></td>
                                <td><?php echo e($states_th->states->name); ?></td>
                                <td><?php echo e($states_th->description); ?></td>
								
                                <td>
                                    <?php if($states_th->active =='1'): ?>
                                        <i class="fa fa-check success"></i>
                                    <?php else: ?>
                                        <i class="fa fa-times danger"></i>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('statesthreefourty.edit', $states_th->id)); ?>"">
                                        <i class="fa fa-pencil info"></i>
                                    </a>
                                    <a href="<?php echo e(route('statesthreefourty.show', $states_th->id)); ?>">
                                        <i class="fa fa-list-alt info"></i>
                                    <a data-method="Delete" data-confirm="Are you sure?" href="<?php echo e(route('statesthreefourty.destroy', $states_th->id)); ?>">
                                        <i class="fa fa-trash-o danger"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->


            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>