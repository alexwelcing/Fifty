

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-form">
                <div class="box-header">
                    <h3 class="box-title">Show <?php echo e($title); ?></h3>
                    <a href="<?php echo e(route('datas.index')); ?>" class="btn btn-success pull-right"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="col-md-12">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($data->title); ?></h3>
                            <div class="pull-right">		                        
		                        <a href="<?php echo e(route('datas.edit', $data->id)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i> Edit</a>
		                        
								<?php if(auth()->user()->roles_id=='1'): ?>
								<a data-method="Delete" data-confirm="Are you sure?" class="btn btn-danger" href="<?php echo e(route('datas.destroy', $data->id)); ?>">
									<i class="fa fa-trash-o danger"></i> Delete
								</a>
								<?php endif; ?>
								<a href="<?php echo e(route('faqs.index', $data->id)); ?>" class="btn btn-success">Categories Faq's</a>		                        
	                    	</div>
                        </div>
						<div class="col-md-12">
							<p><strong>State:</strong> <?php echo e($data->states->name); ?></p>
							<p><strong>First Heading:</strong> <?php echo e($data->first_heading); ?></p>
							<p><strong>Second Heading:</strong> <?php echo e($data->second_heading); ?></p>
						</div>

						<div class="col-md-12">
	                        
						</div>
                        
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>