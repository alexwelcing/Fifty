

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-8">
            <div class="box box-form">
                <div class="box-header">
                    <h3 class="box-title">Create <?php echo e($title); ?></h3>
                    <a href="<?php echo e(route('sectionsdata.index', [$statesthreefourty->id,$section->id])); ?>" class="btn btn-success pull-right"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="col-md-12">
                        
                        <?php echo Form::open(['route' => ['sectionsdata.store', $statesthreefourty,$section]]); ?>


                        <?php echo $__env->make('admin.statesthreefourty.sectiondata.partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Create <?php echo e($title); ?></button>
                        </div>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>