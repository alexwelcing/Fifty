
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="box-login">
	<div class="box-login-body">
		<h3><span><b>Admin</b></span></h3>		
		<form method="POST" class="login-form" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
			<?php echo csrf_field(); ?>			
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
				<input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="<?php echo e(__('E-Mail Address')); ?>" value="<?php echo e(old('email')); ?>" required autofocus />
				<?php if($errors->has('email')): ?>
				<span class="invalid-feedback" role="alert">
					<strong><?php echo e($errors->first('email')); ?></strong>
				</span>
				<?php endif; ?>
			</div>
			
			<div class="form-group input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
				<input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="<?php echo e(__('Password')); ?>" required>
				<?php if($errors->has('password')): ?>
				<span class="invalid-feedback" role="alert">
					<strong><?php echo e($errors->first('password')); ?></strong>
				</span>
				<?php endif; ?>
			</div>
			
			<div class="form-group input-group">
				<div class="checkbox">
					<label for="terms" style="padding-left: 12px;">
						<input class="icheck_flat_20" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Remember Me')); ?>

					</label>
				</div>
			</div>
			
			<div class="form-group btn-grp">
				<div class="login-btn">
					<button type="submit" class="btn btn-block btn-default"><?php echo e(__('Login')); ?></button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>