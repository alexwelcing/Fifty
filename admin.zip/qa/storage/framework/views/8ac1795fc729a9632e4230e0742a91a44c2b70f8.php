<div class="form-group <?php echo ($errors->has('question') ? 'has-error' : ''); ?>">
    <?php echo Form::label('question','Question', ['class' => 'control-label']); ?>

    <?php echo Form::text('question', null, ['class' => 'form-control' . ($errors->has('question') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('question', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('dispensing_fee') ? 'has-error' : ''); ?>">
    <?php echo Form::label('dispensing_fee','Dispensing Fee', ['class' => 'control-label']); ?>

    <?php echo Form::text('dispensing_fee', null, ['class' => 'form-control' . ($errors->has('dispensing_fee') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('dispensing_fee', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('clarifying_detail') ? 'has-error' : ''); ?>">
    <?php echo Form::label('clarifying_detail','Clarifying Detail', ['class' => 'control-label']); ?>

    <?php echo Form::text('clarifying_detail', null, ['class' => 'form-control' . ($errors->has('clarifying_detail') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('clarifying_detail', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('states_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('states_id','States', ['class' => 'control-label']); ?>

    <?php echo Form::select('states_id', $states, null, ['class' => 'form-control' . ($errors->has('states_id') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('states_id', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('question_type') ? 'has-error' : ''); ?>">
    <?php echo Form::label('question_type','Question Type', ['class' => 'control-label']); ?>    
    <?php echo Form::select('question_type', array('1' => 'Reimbursement Requirements', '2' => 'Duplicate Discount Mechanism'), null, ['class' => 'form-control' . ($errors->has('table_rows') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('question_type', '<span class="help-block">:message</span>'); ?>

</div>
<div class="form-group <?php echo ($errors->has('source') ? 'has-error' : ''); ?>">
    <?php echo Form::label('source','Source', ['class' => 'control-label']); ?>

    <?php echo Form::text('source', null, ['class' => 'form-control' . ($errors->has('source') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('source', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('source_link') ? 'has-error' : ''); ?>">
    <?php echo Form::label('source_link','Source Link', ['class' => 'control-label']); ?>

    <?php echo Form::text('source_link', null, ['class' => 'form-control' . ($errors->has('source_link') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('source_link', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>