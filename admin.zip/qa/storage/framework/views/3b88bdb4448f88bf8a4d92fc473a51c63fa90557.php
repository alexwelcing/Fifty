<div class="form-group <?php echo ($errors->has('name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('name','Name', ['class' => 'control-label']); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '') ]); ?>

    <?php echo $errors->first('name', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('abbreviation') ? 'has-error' : ''); ?>">
    <?php echo Form::label('abbreviation','Abbreviation', ['class' => 'control-label']); ?>

    <?php echo Form::text('abbreviation', null, ['class' => 'form-control' . ($errors->has('abbreviation') ? ' is-invalid' : ''), 'maxlength' => 2]); ?>

    <?php echo $errors->first('abbreviation', '<span class="help-block">:message</span>'); ?>

</div>

<div class="form-group <?php echo ($errors->has('active') ? 'has-error' : ''); ?>">
    <?php echo Form::label('active','Active', ['class' => 'control-label']); ?></br>
    <?php echo Form::radio('active', 1); ?> Yes
    <?php echo Form::radio('active', 0); ?> No
    <?php echo $errors->first('active', '<span class="help-block">:message</span>'); ?>

</div>