<!-- /.box-header -->
<div class="box-body table-responsive no-padding">
    <table class="table table-hover">
        <tbody>
            <tr>
                <th>Sr.</th>
                <th>Title</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($k+1); ?></td>
                <td><a href="<?php echo e(route('sections.show', [$statesthreefourty->id,$section->id])); ?>"><?php echo $section->title; ?></a></td>
                <td><?php echo $section->description; ?></td>
                <td>
                  <?php if($section->active =='1'): ?>
                   <i class="fa fa-check success"></i>
                    <?php else: ?>
                     <i class="fa fa-times danger"></i>
                      <?php endif; ?>
                    </td>
                <td>
                    <a href="<?php echo e(route('sections.edit', [$statesthreefourty->id, $section->id])); ?>">
                        <i class="fa fa-pencil info"></i>
                    </a>
                    <a data-method="Delete" data-confirm="Are you sure?" href="<?php echo e(route('sections.destroy', [$statesthreefourty->id, $section->id])); ?>">
                        <i class="fa fa-trash-o danger"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<!-- /.box-body -->